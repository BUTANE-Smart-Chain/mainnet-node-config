#!/usr/bin/env bash

red=$(tput setaf 1)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
lila=$(tput setaf 4)
pink=$(tput setaf 5)
blue=$(tput setaf 6)
white=$(tput setaf 7)
black=$(tput setaf 8)

bg_red=$(tput setab 1)
bg_green=$(tput setab 2)
bg_yellow=$(tput setab 3)
bg_lila=$(tput setab 4)
bg_pink=$(tput setab 5)
bg_blue=$(tput setab 6)
bg_white=$(tput setab 7)
bg_black=$(tput setab 8)

bold=$(tput bold)
reset=$(tput sgr0)

# Indicators
heading ()
{
    echo "    ${lila}==>${reset}${bold} $1${reset}"
}

success ()
{
    echo "    ${green}==>${reset}${bold} $1${reset}"
}

info ()
{
    echo "    ${blue}==>${reset}${bold} $1${reset}"
}

warning ()
{
    echo "    ${yellow}==>${reset}${bold} $1${reset}"
}

error ()
{
    echo "    ${red}==>${reset}${bold} $1${reset}"
}

# Colored Text
text_red ()
{
    echo "${red}$1${reset}"
}

text_green ()
{
    echo "${green}$1${reset}"
}

text_yellow ()
{
    echo "${yellow}$1${reset}"
}

text_lila ()
{
    echo "${lila}$1${reset}"
}

text_pink ()
{
    echo "${pink}$1${reset}"
}

text_blue ()
{
    echo "${blue}$1${reset}"
}

text_white ()
{
    echo "${white}$1${reset}"
}

text_black ()
{
    echo "${black}$1${reset}"
}

# Styles
text_bold ()
{
    echo "${bold}"
}

text_reset ()
{
    echo "${reset}"
}

# Helpers
divider ()
{
        text_lila "    ==============================================================="
}

paragraph ()
{
  text_white "$1" | fold -w67 | paste -sd'\n' -
}

heading "Checking for Configuration Files"

cd "$HOME"

if [[ ! -f "app.json" || ! -f ".env" || ! -f "peers.json" ]]; then
    echo "One of the configuration files is missing!"
    exit 1
fi

if [ ! -d "$HOME/crypto" ]; then
    echo "Crypto configuration directory could not be found!"
    exit 1
fi

success "Configuration Files Found!"
shopt -s expand_aliases

cd "$HOME"

#!/usr/bin/env bash

readNonempty() {
    prompt=${1}
    answer=""
    while [ -z "${answer}" ] ; do
        read -p "${prompt}" answer
    done
    echo "${answer}"
}

if [ "$EID" == "0" ]; then
    echo "Core installation must not be run as root!"
    exit 1
fi

# Ensure that no unwanted prompts show up
export DEBIAN_FRONTEND=noninteractive

# Detect pkg type
DEB=$(which apt-get)

# Detect SystemV / SystemD
SYS=$([[ -L "/sbin/init" ]] && echo 'SystemD' || echo 'SystemV')

if [[ -n $DEB ]]; then
    success "Running install for Debian derivate"
else
    heading "Not supported system"
    exit 1;
fi

if [[ $(locale -a | grep ^en_US.UTF-8) ]] || [[ $(locale -a | grep ^en_US.utf8) ]]; then
    if ! grep -E "(en_US.UTF-8)" "$HOME/.bashrc"; then
        # Setting the bashrc locale
        {
            echo "export LC_ALL=en_US.UTF-8"
            echo "export LANG=en_US.UTF-8"
            echo "export LANGUAGE=en_US.UTF-8"
        } >> "$HOME/.bashrc"

        # Setting the current shell locale
        export LC_ALL="en_US.UTF-8"
        export LANG="en_US.UTF-8"
        export LANGUAGE="en_US.UTF-8"
    fi
else
    # Install en_US.UTF-8 Locale
    sudo locale-gen en_US.UTF-8
    sudo update-locale LANG=en_US.UTF-8

    # Setting the current shell locale
    export LC_ALL="en_US.UTF-8"
    export LANG="en_US.UTF-8"
    export LANGUAGE="en_US.UTF-8"

    # Setting the bashrc locale
    {
        echo "export LC_ALL=en_US.UTF-8"
        echo "export LANG=en_US.UTF-8"
        echo "export LANGUAGE=en_US.UTF-8"
    } >> "$HOME/.bashrc"
fi

# Wait For Apt To Unlock

while fuser /var/lib/dpkg/lock >/dev/null 2>&1 ; do
    echo "Waiting for other software managers to finish..."

    sleep 1
done

heading "Installing system dependencies..."

echo 'libssl1.1 libraries/restart-without-asking boolean true' | sudo debconf-set-selections

sudo apt-get update
sudo apt-get install -y curl apt-transport-https update-notifier

success "Installed system dependencies!"

heading "Installing node.js & npm..."

sudo rm -rf /usr/local/{lib/node{,/.npm,_modules},bin,share/man}/{npm*,node*,man1/node*}
sudo rm -rf ~/{.npm,.forever,.node*,.cache,.nvm}

sudo wget --quiet -O - https://deb.nodesource.com/gpgkey/nodesource.gpg.key | sudo apt-key add -
(echo "deb https://deb.nodesource.com/node_14.x $(lsb_release -s -c) main" | sudo tee /etc/apt/sources.list.d/nodesource.list)
sudo apt-get update
sudo apt-get install nodejs -y

success "Installed node.js & npm!"

heading "Installing Yarn..."

curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -
(echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list)

sudo apt-get update
sudo apt-get install -y yarn

success "Installed Yarn!"

heading "Export Paths..."

# Ensure that yarn is available for later use
export PATH="$(yarn global bin):$PATH"

if [ -f "$HOME/.bash_profile" ]; then
    echo 'export PATH="$HOME/bin:$HOME/.local/bin:$(yarn global bin):$PATH"' >> "$HOME/.bash_profile"
elif [ -f "$HOME/.bashrc" ]; then
    echo 'export PATH="$HOME/bin:$HOME/.local/bin:$(yarn global bin):$PATH"' >> "$HOME/.bashrc"
fi

if [ -f "$HOME/.profile" ]; then
    echo 'export PATH="$HOME/bin:$HOME/.local/bin:$(yarn global bin):$PATH"' >> "$HOME/.profile"
fi

success "Exported Paths!"

heading "Installing PM2..."

sudo yarn global add pm2
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 500M
pm2 set pm2-logrotate:compress true
pm2 set pm2-logrotate:retain 7

success "Installed PM2!"

heading "Installing program dependencies..."

sudo apt-get install build-essential libcairo2-dev pkg-config libtool autoconf automake python libpq-dev jq zip unzip -y


wget https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64 -O jq
chmod +x jq
sudo mv jq /usr/bin

success "Installed program dependencies!"

heading "Installing PostgreSQL..."

sudo apt-get update
sudo apt-get install postgresql postgresql-contrib -y

success "Installed PostgreSQL!"

heading "Installing NTP..."

sudo timedatectl set-ntp off > /dev/null 2>&1 # disable the default systemd timesyncd service

sudo apt-get install ntp -yyq

sudo ntpd -gq

success "Installed NTP!"

heading "Installing jemalloc..."

sudo apt-get install -y libjemalloc-dev

success "Installed jemalloc!"

heading "Installing system updates..."

sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get upgrade -yqq
sudo apt-get dist-upgrade -yqq
sudo apt-get autoremove -yyq
sudo apt-get autoclean -yq

success "Installed system updates!"

PUBLIC_IP=$(sudo ifconfig | fgrep "inet " | fgrep -v "inet 127." | egrep -o "inet ([0-9]+\.?){4}" | awk '{print $2}' | head -n 1)

heading "Installing ARK Core..."

yarn global add @arkecosystem/core@latest

success "Installed ARK Core!"
heading "Configuring Core"

mkdir -p $HOME/.config/bbc-core/mainnet/crypto


mv .env app.json peers.json -t $HOME/.config/bbc-core/mainnet

mv crypto/* $HOME/.config/bbc-core/mainnet/crypto

cd $HOME/.config/bbc-core/mainnet


cat > delegates.json << EOF
{
    "secrets": []
}
EOF


cd

success "Configured ARK Core!"

# setup postgres username, password and database
read -p "Would you like to configure the database? [y/N]: " choice

if [[ "$choice" =~ ^(yes|y|Y) ]]; then
    choice=""
    while [[ ! "$choice" =~ ^(yes|y|Y) ]] ; do
        databaseUsername=$(readNonempty "Enter the database username: ")
        databasePassword=$(readNonempty "Enter the database password: ")
        databaseName=$(readNonempty "Enter the database name: ")

        echo "database username: ${databaseUsername}"
        echo "database password: ${databasePassword}"
        echo "database name: ${databaseName}"
        read -p "Proceed? [y/N]: " choice
    done

    ark env:set --key=CORE_DB_USERNAME --value="${databaseUsername}" --token="bbc" --network="mainnet"
    ark env:set --key=CORE_DB_PASSWORD --value="${databasePassword}" --token="bbc" --network="mainnet"
    ark env:set --key=CORE_DB_DATABASE --value="${databaseName}" --token="bbc" --network="mainnet"

    userExists=$(sudo -i -u postgres psql -tAc "SELECT 1 FROM pg_user WHERE usename = '${databaseUsername}'")
    databaseExists=$(sudo -i -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname = '${databaseName}'")

    if [[ $userExists == 1 ]]; then
        read -p "The database user ${databaseUsername} already exists, do you want to recreate it? [y/N]: " choice

        if [[ "$choice" =~ ^(yes|y|Y) ]]; then
            if [[ $databaseExists == 1 ]]; then
                sudo -i -u postgres psql -c "ALTER DATABASE ${databaseName} OWNER TO postgres;"
            fi
            sudo -i -u postgres psql -c "DROP USER ${databaseUsername}"
            sudo -i -u postgres psql -c "CREATE USER ${databaseUsername} WITH PASSWORD '${databasePassword}' CREATEDB;"
        fi
    else
        sudo -i -u postgres psql -c "CREATE USER ${databaseUsername} WITH PASSWORD '${databasePassword}' CREATEDB;"
    fi

    if [[ $databaseExists == 1 ]]; then
        read -p "The database ${databaseName} already exists, do you want to overwrite it? [y/N]: " choice

        if [[ "$choice" =~ ^(yes|y|Y) ]]; then
            sudo -i -u postgres psql -c "DROP DATABASE ${databaseName};"
            sudo -i -u postgres psql -c "CREATE DATABASE ${databaseName} WITH OWNER ${databaseUsername};"
        elif [[ "$choice" =~ ^(no|n|N) ]]; then
            sudo -i -u postgres psql -c "ALTER DATABASE ${databaseName} OWNER TO ${databaseUsername};"
        fi
    else
        sudo -i -u postgres psql -c "CREATE DATABASE ${databaseName} WITH OWNER ${databaseUsername};"
    fi
fi

echo 'export LESS="-RS"' >> "$HOME/.bashrc"
echo 'bbc() { $(yarn global dir)/node_modules/@arkecosystem/core/bin/run "$@" --token="bbc" --network="mainnet"; }' >> "$HOME/.bashrc"

source "$HOME/.bashrc"
source "$HOME/.profile"
